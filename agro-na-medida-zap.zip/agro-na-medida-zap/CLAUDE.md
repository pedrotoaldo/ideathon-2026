# Agro na Medida ZAP — instruções para o Claude Code

## O que é
Assistente no WhatsApp para pequenos produtores rurais (Ideathon Mandaguari 2026, Desafio Agro).
O produtor manda texto ou áudio e recebe:
1. **Conta da safra:** custo por hectare, custo por saca, produtividade mínima, preço de equilíbrio e 3 cenários.
2. **Reforma tributária:** perfil provável (LC 214/2025), explicação simples e checklist para o contador.

Na apresentação, o público escaneia um **QR code** e conversa com o bot ao vivo. Robustez da demo é prioridade.

## Leia antes de codar
| Arquivo | Para quê |
| --- | --- |
| `docs/SPEC.md` | O que construir, requisitos e critérios de aceite |
| `docs/PLAN.md` | Ordem de execução em etapas, com checkboxes |
| `docs/ARCHITECTURE.md` | Stack, fluxos do n8n, banco, integrações |
| `docs/CONVERSA.md` | Textos do bot, menu, intenções, exemplos |
| `docs/DEMO_QR.md` | Runbook da demo ao vivo e proteção contra abuso |
| `prompts/` | Prompts do agente e da extração |
| `content/reforma_tributaria_base.md` | Única fonte permitida para respostas tributárias |
| `src/calc/safra.cjs` | Cálculo determinístico (vai para o Code node do n8n) |

## Regras inegociáveis
1. **A IA não calcula.** Todo número sai de `src/calc/safra.cjs`. O LLM só extrai dados e explica resultados.
2. **A IA não recomenda regime tributário.** Nunca "opte por" ou "fique como". Só descreve perfil provável e manda ao contador.
3. **Respostas tributárias só com `content/reforma_tributaria_base.md`.** Fora disso: "não sei com segurança" + encaminhamento.
4. **Escopo fechado:** safra, custos, preço, clima informativo e reforma tributária. Outros assuntos recebem a resposta padrão de fora de escopo.
5. **Sem previsão de colheita ou de preço.** Clima é informação de fonte (Open-Meteo), nunca previsão de produtividade.
6. **Demo pública:** não pedir CPF, CNPJ, dados bancários ou nomes reais. Incentivar dados de exemplo.
7. **Todo texto para o usuário em português do Brasil**, frases curtas, linguagem de produtor.

## Convenções
- Código JS (Node 21+). O módulo de cálculo é `src/calc/safra.cjs`, sem dependências e sem `import`/`export`, porque é colado no Code node do n8n. Depois de mudar, rode `npm run build:n8n` para gerar `n8n/code-nodes/calcular_safra.js`.
- Testes: `npm test` (node:test nativo).
- Valores em reais com 2 casas; áreas convertidas para hectare (1 alqueire paulista = 2,42 ha).
- Segredos só em `.env` (nunca commitar). Ver `.env.example`.
- Workflows do n8n exportados em `n8n/workflows/*.json` depois de prontos.

## Comandos
```bash
npm test                     # testes do cálculo
docker compose up -d                 # Evolution API + Postgres + Redis
psql "$DATABASE_URL" -f db/schema.sql
```

## Subagentes disponíveis (`.claude/agents/`)
- `revisor-guardrails`: revisa prompts, conteúdo e respostas contra as regras acima. Use antes de cada demo.
- `qa-conversa`: roda os roteiros de `docs/CONVERSA.md` contra o webhook e aponta falhas.
- `calc-engenheiro`: mexe só em `src/calc/` com testes.

## Definição de pronto para a demo
Todos os itens da Etapa 5 de `docs/PLAN.md` marcados, `npm test` verde e `revisor-guardrails` sem bloqueios.
