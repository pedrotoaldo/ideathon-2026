# Agro na Medida ZAP

Assistente de WhatsApp para pequenos produtores: conta da safra e reforma tributária. Ideathon Mandaguari 2026, Desafio Agro.

## Começar no Claude Code
1. Abra esta pasta no Claude Code.
2. Os PDFs do Ideathon e o estudo de público já estão em `docs/referencias/`.
3. Cole o pedido abaixo:

```
Leia CLAUDE.md, docs/SPEC.md, docs/PLAN.md e docs/ARCHITECTURE.md.
Entre em modo de planejamento e me mostre como vai executar a Etapa 0 e a Etapa 1 do PLAN,
usando o subagente calc-engenheiro para a Etapa 1 em paralelo.
Não mexa nos workflows do n8n sem me mostrar o desenho dos nós antes.
```

4. Depois de cada etapa, peça: "rode o qa-conversa" e, antes da banca, "rode o revisor-guardrails".

## Estrutura
```
CLAUDE.md                     regras e mapa do projeto para o Claude Code
docs/SPEC.md                  o que construir e critérios de aceite
docs/PLAN.md                  etapas com checkboxes
docs/ARCHITECTURE.md          stack, workflow do n8n, estados, integrações
docs/CONVERSA.md              textos do bot e roteiros de teste
docs/DEMO_QR.md               runbook da demo ao vivo com QR code
docs/referencias/             estudo de público e PDFs do Ideathon
prompts/                      prompts do LLM (extração e tributário)
content/                      base tributária (pendente de revisão por contador)
src/calc/                     cálculo da safra + testes
scripts/build-n8n.mjs         gera o código do Code node do n8n
n8n/                          código e workflows exportados
db/                           schema do Postgres
.claude/agents/               subagentes: revisor-guardrails, qa-conversa, calc-engenheiro
docker-compose.yml            Evolution API + Postgres + Redis
```

## Comandos
```bash
npm test               # testes do cálculo (10 casos, incluindo o exemplo do vídeo)
npm run build:n8n      # gera n8n/code-nodes/calcular_safra.js
docker compose up -d   # infra da demo
```
