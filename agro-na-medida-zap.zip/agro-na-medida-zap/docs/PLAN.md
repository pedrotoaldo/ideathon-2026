# PLAN — execução até a banca (11/11/2026, 18h30)

Regra: terminar e testar cada etapa antes de abrir a próxima. Se o tempo apertar, as etapas 6 e 7 são cortáveis; as etapas 0 a 5 não.

| Etapa | Entrega | Tempo-alvo | Pode rodar em paralelo? |
| --- | --- | --- | --- |
| 0 | Infra no ar (Evolution + Postgres + Redis) e número conectado | 1 h | Sim, com a etapa 1 |
| 1 | Cálculo da safra testado | 30 min | Sim (subagente `calc-engenheiro`) |
| 2 | Esqueleto do fluxo no n8n: recebe, filtra, deduplica, limita, responde | 1 h 30 | Não |
| 3 | Conta da safra ponta a ponta (texto e áudio) | 2 h | Não |
| 4 | Caminho tributário com base revisada | 1 h 30 | Conteúdo em paralelo |
| 5 | Endurecimento para a demo pública | 1 h 30 | Não |
| 6 | Extras: resumo, clima, apagar dados | 1 h | Sim |
| 7 | Ensaio e plano B | 1 h | Não |

## Etapa 0 — Infra
- [ ] Copiar `.env.example` para `.env` e preencher
- [ ] `docker compose up -d` (Evolution API, Postgres, Redis)
- [ ] `psql "$DATABASE_URL" -f db/schema.sql`
- [ ] Criar instância na Evolution (`integration: WHATSAPP-BAILEYS`) e ler o QR com o **chip dedicado da demo**
- [ ] Configurar webhook da instância apontando para o n8n (evento `MESSAGES_UPSERT`)
- [ ] Teste: mandar "oi" e ver o payload chegar no n8n

## Etapa 1 — Cálculo
- [ ] `npm test` verde (já existe implementação de referência)
- [ ] Conferir o exemplo de referência da SPEC seção 6
- [ ] `npm run build:n8n` e colar `n8n/code-nodes/calcular_safra.js` num Code node "Calcular safra" (modo Run Once for All Items; entrada `acao`: calcular | e_se | perfil)

## Etapa 2 — Esqueleto do fluxo
- [ ] Webhook → normalizar payload (número, tipo, texto, id, fromMe, grupo)
- [ ] Descartar `fromMe`, grupos e status
- [ ] Idempotência: `INSERT ... ON CONFLICT DO NOTHING` em `mensagem` pelo `message_id`
- [ ] Kill switch: ler `config.bot_ativo`
- [ ] Rate limit por número (N01)
- [ ] Carregar ou criar `conversa` (estado + dados parciais)
- [ ] Primeiro contato → `BOAS_VINDAS`
- [ ] Enviar resposta via Evolution `POST /message/sendText/{instance}`
- [ ] Teste: 2 celulares mandando "oi" ao mesmo tempo

## Etapa 3 — Conta da safra
- [ ] Roteador de intenção (regra simples primeiro: números do menu e palavras-chave; LLM só se ambíguo)
- [ ] Áudio: baixar mídia em base64 pela Evolution → transcrever → seguir como texto
- [ ] Extração com `prompts/extracao_safra.md` (saída JSON validada; se inválida, perguntar de novo)
- [ ] Máquina de estados: `coletando_safra` → `confirmando_safra` → `resultado_safra`
- [ ] Converter alqueire para ha antes do cálculo
- [ ] Formatar resposta com `RESULTADO_SAFRA` (CONVERSA.md)
- [ ] "E se..." recalcula com o dado alterado
- [ ] Rodar Roteiros A e B (subagente `qa-conversa`)

## Etapa 4 — Reforma tributária
- [ ] Carregar `content/reforma_tributaria_base.md` no prompt do agente tributário (é curto; RAG com pgvector fica para o piloto)
- [ ] Fluxo de perguntas do perfil (F10) e regra de perfil provável (ARCHITECTURE seção 5)
- [ ] Toda resposta termina com a frase padrão e oferta de checklist
- [ ] Rodar Roteiro C
- [ ] Subagente `revisor-guardrails` sobre prompts e conteúdo

## Etapa 5 — Endurecimento para a demo pública
- [ ] Filtro de fora de escopo e prompt injection (Roteiro D)
- [ ] Limite de tamanho de texto e duração de áudio
- [ ] Fallback por menu numérico se o LLM falhar (N10)
- [ ] Limite de gasto diário no provedor de IA
- [ ] Teste de carga: script com 30 envios simultâneos ao webhook (`scripts/carga.mjs`, a criar)
- [ ] Testar kill switch
- [ ] Gerar QR code `https://wa.me/55DDDNUMERO?text=Oi` para o slide

## Etapa 6 — Extras (cortáveis)
- [ ] "resumo" (F14)
- [ ] Clima via Open-Meteo (F15)
- [ ] "apagar meus dados" (F16)
- [ ] Query de acompanhamento da demo (F17)

## Etapa 7 — Ensaio
- [ ] Ensaio completo com cronômetro, seguindo `docs/DEMO_QR.md`
- [ ] Gravar vídeo da demo funcionando (plano B)
- [ ] Exportar workflows para `n8n/workflows/`
- [ ] Revisão final do `revisor-guardrails`

## Como usar subagentes nesta execução
- Etapas 0 e 1 em paralelo: o agente principal sobe a infra enquanto `calc-engenheiro` valida o cálculo.
- Na etapa 4, um subagente revisa o conteúdo tributário enquanto o principal monta o fluxo.
- `qa-conversa` ao fim das etapas 3, 4 e 5. `revisor-guardrails` ao fim das etapas 4 e 7.
- O agente principal é o único que mexe nos workflows do n8n, para evitar conflito.
