# ARCHITECTURE — Agro na Medida ZAP

## 1. Stack

| Camada | Escolha para a demo | Por quê | Piloto (depois) |
| --- | --- | --- | --- |
| Canal | WhatsApp via **Evolution API v2** (`evoapicloud/evolution-api:v2.3.7`), integração `WHATSAPP-BAILEYS` | Sobe em minutos, sem aprovação da Meta | Mesma Evolution com `WHATSAPP-BUSINESS` (Cloud API oficial) |
| Orquestração | **n8n** (instância própria da equipe) | Equipe já domina; fluxos visuais | Igual, em modo fila |
| Banco | **PostgreSQL 16** | Estado da conversa, logs, idempotência | + pgvector para RAG |
| Cache da Evolution | Redis 7 | Requisito da Evolution | Igual |
| LLM | API compatível com OpenAI via HTTP Request (`LLM_BASE_URL`) | Troca OpenAI ↔ Ollama só mudando o `.env` | Avaliar custo |
| Transcrição | Whisper (OpenAI `audio/transcriptions`) ou local | Português bom e rápido | Igual |
| Clima | **Open-Meteo** (sem API key) | Grátis e simples | Igual |
| Cálculo | `src/calc/safra.cjs` dentro de um Code node | Determinístico e testado | Igual |

**Rede:** a Evolution conecta para fora (WhatsApp) e chama o n8n por webhook na rede interna. Não precisa de IP público. O servidor só precisa estar ligado e com internet durante a apresentação, em qualquer lugar.

## 2. Visão geral

```
Celular da plateia ──WhatsApp──> Evolution API ──webhook──> n8n "agro-zap-entrada"
                                     ^                        │
                                     │ sendText               ├─> Postgres (estado, logs, limites)
                                     └────────────────────────┤
                                                              ├─> Whisper (áudio → texto)
                                                              ├─> LLM (classificar/extrair, redigir tributário)
                                                              ├─> Code: safra.cjs (números)
                                                              └─> Open-Meteo (clima, P1)
```

## 3. Workflow principal no n8n: `agro-zap-entrada`

| # | Nó | Tipo | Função |
| --- | --- | --- | --- |
| 1 | Webhook `POST /webhook/agro-zap` | Webhook (responde 200 na hora) | Recebe `MESSAGES_UPSERT` |
| 2 | Normalizar | Code | Extrai `numero` (remoteJid sem sufixo), `message_id`, `fromMe`, `isGroup`, `tipo` (texto, audio, outro), `texto`, `duracao_audio` |
| 3 | Descartar | IF | `fromMe`, grupo (`@g.us`), status (`status@broadcast`), tipo `outro` → fim (tipo outro responde `SO_TEXTO_AUDIO`) |
| 4 | Idempotência | Postgres | `INSERT INTO mensagem(message_id, ...) ON CONFLICT DO NOTHING RETURNING id`; vazio → fim |
| 5 | Kill switch e limite | Postgres | Lê `config.bot_ativo` e conta mensagens do número nos últimos 10 min |
| 6 | Bloqueios | IF | Inativo → `MANUTENCAO`; acima do limite → `LIMITE` (uma vez por janela) |
| 7 | Áudio | IF + HTTP | `POST /chat/getBase64FromMediaMessage/{instance}` → `POST {LLM_BASE_URL}/audio/transcriptions` → `texto` |
| 8 | Carregar conversa | Postgres | `SELECT ... FOR UPDATE` em `conversa` (cria se não existe) |
| 9 | Cérebro | Code | Máquina de estados (seção 4). Decide: responder texto fixo, chamar extração, calcular, ou chamar redator tributário |
| 10 | Extração | HTTP (LLM) | `prompts/extracao_safra.md`, `response_format: json_schema` |
| 11 | Calcular safra | Code | Conteúdo de `src/calc/safra.cjs` + formatação |
| 12 | Redator tributário | HTTP (LLM) | `prompts/agente_sistema.md` + `content/reforma_tributaria_base.md` |
| 13 | Clima (P1) | HTTP | Open-Meteo geocoding + forecast |
| 14 | Salvar estado | Postgres | Atualiza `conversa.estado` e `conversa.dados` |
| 15 | Enviar | HTTP | `POST /message/sendText/{instance}` com `{ number, text }` |
| 16 | Log | Postgres | `resposta` com intenção, latência, versão do prompt |
| 17 | Erro | Error Trigger (workflow separado) | Envia `ERRO_TEMPORARIO` ao número e grava erro |

Dica: o roteamento por números do menu e palavras-chave é feito no Code node, sem LLM. O LLM só entra quando a mensagem é ambígua ou precisa de extração. Isso reduz latência e custo com a plateia.

**Corrida por número:** duas mensagens do mesmo número ao mesmo tempo podem disputar o estado. O `SELECT ... FOR UPDATE` dentro de uma transação, ou `pg_advisory_xact_lock(hashtext(numero))`, resolve.

**Áudio do iPhone:** há relato de erro 400 em `getBase64FromMediaMessage` com áudio vindo de iOS nas versões 2.3.7 e 2.4.0-rc2 ([issue #2550](https://github.com/evolution-foundation/evolution-api/issues/2550)). Testar com um iPhone na Etapa 3. Alternativa: ativar o envio de base64 no próprio webhook da instância e ler a mídia do payload.

## 4. Máquina de estados (nó "Cérebro")

| Estado | Entrada | Ação | Próximo estado |
| --- | --- | --- | --- |
| `novo` | qualquer | `BOAS_VINDAS` + `MENU` | `menu` |
| `menu` | "1" / intenção safra | `PEDE_SAFRA` | `coletando_safra` |
| `menu` | "2" / intenção reforma | `PERGUNTA_TIPO_PESSOA` | `coletando_perfil` |
| `menu` | "3" / pede pessoa | `ENCAMINHAMENTO` | `menu` |
| `coletando_safra` | texto ou áudio | extrair → mesclar em `dados.safra` → faltou campo? pergunta 1 campo : `CONFIRMA_DADOS` | `coletando_safra` ou `confirmando_safra` |
| `confirmando_safra` | sim | calcular → `RESULTADO_SAFRA` + `OFERTA_PROXIMO` | `resultado_safra` |
| `confirmando_safra` | correção | extrair e mesclar → `CONFIRMA_DADOS` | `confirmando_safra` |
| `resultado_safra` | "e se ..." | extrair alteração → recalcular → `RESULTADO_SAFRA` | `resultado_safra` |
| `coletando_perfil` | respostas | preencher `dados.perfil` (tipo, receita, integrado, outra empresa) | `perfil_pronto` quando completo |
| `perfil_pronto` | — | regra de perfil (seção 5) + `PERFIL_RESULTADO` + `CHECKLIST` | `tributario_livre` |
| `tributario_livre` | pergunta | redator tributário com base revisada | `tributario_livre` |
| qualquer | "menu", "voltar" | `MENU` | `menu` |
| qualquer | "resumo" | `RESUMO` | mantém |
| qualquer | fora de escopo | `FORA_ESCOPO` | mantém |
| qualquer | "apagar meus dados" | apaga e confirma | `novo` |

Campos obrigatórios da safra: `area`, `custo_total`, `produtividade_esperada`, `preco`. Cultura é opcional (padrão "safra").

## 5. Regra de perfil provável (determinística, não é LLM)

```
limite = config.limite_receita_nao_contribuinte   (3.600.000, atualizado pelo IPCA)
se receita >= limite                → "Pela receita informada, você estaria acima do limite e seria contribuinte do IBS/CBS."
senão se integrado                  → "Produtor integrado tem tratamento próprio: não contribuinte, salvo se optar pelo regime regular."
senão                               → "Pela receita informada, você seria não contribuinte, com a possibilidade de optar pelo regime regular."
se receita >= 0,8 × limite          → acrescentar alerta "perto do limite"
se tem outra empresa rural          → acrescentar "as receitas podem ser somadas para o limite: revise com seu contador"
sempre                              → FRASE_PADRAO_TRIBUTARIA + CHECKLIST
```

## 6. Banco de dados
Ver `db/schema.sql`. Tabelas: `config`, `conversa`, `mensagem`, `resposta`, `encaminhamento`.

## 7. Integrações (referência rápida)

| Chamada | Método e rota | Corpo mínimo |
| --- | --- | --- |
| Enviar texto | `POST {EVOLUTION_URL}/message/sendText/{EVOLUTION_INSTANCE}` (header `apikey`) | `{ "number": "5544...", "text": "..." }` |
| Mídia em base64 | `POST {EVOLUTION_URL}/chat/getBase64FromMediaMessage/{EVOLUTION_INSTANCE}` | `{ "message": { "key": { "id": "<message_id>" } } }` |
| Transcrever | `POST {LLM_BASE_URL}/audio/transcriptions` (multipart) | `file`, `model`, `language=pt` |
| LLM | `POST {LLM_BASE_URL}/chat/completions` | `model`, `messages`, `response_format` |
| Geocodificar | `GET https://geocoding-api.open-meteo.com/v1/search?name=Mandaguari&count=1&language=pt` | — |
| Previsão | `GET https://api.open-meteo.com/v1/forecast?latitude=..&longitude=..&daily=precipitation_sum,temperature_2m_max,temperature_2m_min&timezone=America/Sao_Paulo&forecast_days=5` | — |

Conferir os corpos exatos na documentação da versão instalada antes de codar.

## 8. Segurança
- `apikey` da Evolution e chave do LLM só no `.env` e nas credenciais do n8n.
- Porta 8080 da Evolution só na rede interna.
- Webhook do n8n com path difícil de adivinhar ou header secreto.
- Sem dados pessoais sensíveis no prompt do LLM; o número de telefone não vai para o LLM.
